function pic_xy = p_mkde(p_train, t_train, h)


% input data p_train : dim * number of records
%            t_train : the data point in order to estimate mkde (d*1) vector
%            h : smoothing parameter


[dim, num] = size(t_train);
Sxy  = cov(t_train');
detS = det(Sxy);

%%
sum_res = 0;
for i = 1 : num
    p = (p_train - t_train(:, i))' * (Sxy^(-1)) * (p_train - t_train(:, i));
    sum_res = sum_res + 1 / sqrt((2 * pi)^ dim * detS) * exp(-p / (2 * h^2));
end


pic_xy = 1 / (num * h ^ dim) * sum_res;