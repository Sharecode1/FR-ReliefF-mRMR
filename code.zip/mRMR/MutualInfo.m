function [Ixy, lambda] = MutualInfo(p_train, t_train)

% Ixy   
% lambda


p_train = p_train';
t_train = t_train';


d = 2;
sum_res = 0;
len = length(p_train);
train = [p_train; t_train];
hx = (4 / (d + 2)) ^ (1 / (d + 4)) * len^(-1 / (d + 4));

%%  
for i = 1 : len
    pxy = p_mkde([p_train(i), t_train(i)]', train, hx);
    px  = p_mkde( p_train(i), p_train, hx);
    py  = p_mkde( t_train(i), t_train, hx);
    sum_res = sum_res + log(pxy / (px * py));
end


Ixy    = sum_res / len;
lambda = sqrt(1 - exp(-2 * Ixy));