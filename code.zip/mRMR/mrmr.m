function save_index = mrmr(p_train, t_train, M)
% p_train 
% t_train 
% M      
 

N_Dim = size(p_train, 2);
Mic = ones(1, N_Dim);
save_index = ones(1, M);


for i = 1 : N_Dim
   Mic(i) = MutualInfo(p_train(:, i), t_train);
end


[~, idxs] = sort(-Mic);      
save_index(1) = idxs(1);     
KMAX = min(1000, N_Dim);     
idxleft = idxs(2 : KMAX);    

%%  
for k = 2 : M
   ncand = length(idxleft);                                    
   curlastfea = length(save_index);                           

   for i = 1 : ncand
      t_mic(i) = MutualInfo(p_train(:, idxleft(i)), t_train);  
      mic_array(idxleft(i), curlastfea) = getmultimi(p_train(:, save_index(curlastfea)), ...
          p_train(:, idxleft(i)));
                                                               
      c_mic(i) = mean(mic_array(idxleft(i), :));              
   end

   [~, save_index(k)] = max(t_mic(1 : ncand) ./ (c_mic(1 : ncand) + 0.01));
   tmpidx = save_index(k); 
   save_index(k) = idxleft(tmpidx); 
   idxleft(tmpidx) = [];

end
 
end