function feature_mic = getmultimi(p_train, t_train) 

feature_mic = ones(1, size(p_train, 2));
for i = 1 : size(p_train, 2)
   feature_mic(i) = MutualInfo(p_train(:, i), t_train);
end