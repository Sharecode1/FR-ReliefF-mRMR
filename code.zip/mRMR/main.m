warning off             
close all              
clear                   
clc                     

res = xlsread('data.xlsx');

num_size = 0.7;                              
outdim = 1;                                  
num_samples = size(res, 1);                 
res = res(randperm(num_samples), :);         
num_train_s = round(num_size * num_samples); 
f_ = size(res, 2) - outdim;             

P_train = res(1: num_train_s, 1: f_)';
T_train = res(1: num_train_s, f_ + 1: end)';
M = size(P_train, 2);

P_test = res(num_train_s + 1: end, 1: f_)';
T_test = res(num_train_s + 1: end, f_ + 1: end)';
N = size(P_test, 2);


[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);


p_train = p_train'; p_test = p_test';
t_train = t_train'; t_test = t_test';


k = 10;                
save_index = mrmr(p_train, t_train, k);

disp('Remaied No.feature��')
disp(save_index)

besterror=inf;       
for i=1:k            
    p_train1 = p_train(:, save_index(1:i));  
    p_test1  = p_test (:, save_index(1:i));
    save_index(1:i)

  rand('seed',10);
    rand(0,10)
    trees =5;                                    
    leaf  = 5;                                  
    OOBPrediction = 'on';                            
    OOBPredictorImportance = 'on';                    
    Method = 'regression';                            
    net = TreeBagger(trees, p_train1, t_train, 'OOBPredictorImportance', OOBPredictorImportance,...
    'Method', Method, 'OOBPrediction', OOBPrediction, 'minleaf', leaf);
    %importance = net.OOBPermutedPredictorDeltaError;  


   t_sim1 = predict(net, p_train1);
   t_sim2 = predict(net, p_test1 );

  T_sim1 = mapminmax('reverse', t_sim1, ps_output);
  T_sim2 = mapminmax('reverse', t_sim2, ps_output);


  error1 = sqrt(sum((T_sim1' - T_train).^2) ./ M);
  error2 = sqrt(sum((T_sim2' - T_test ).^2) ./ N);

     % R2
  R21(i)=1-sum((T_train-T_sim1').^2)/sum((T_train -  mean(T_train)).^2);  
  R22(i)=1-sum((T_test- T_sim2').^2)/sum((T_test -  mean(T_test)).^2);  
  disp(['Calibration R2��', num2str(R21)])
  disp(['Validation R2��', num2str(R22)])

%MAE
  MAE1(i) = sum(abs(T_train - T_sim1')) ./ M ;
  MAE2(i) = sum(abs(T_test - T_sim2' )) ./ N ;
  disp(['Calibration MAE��', num2str(MAE1)])
  disp(['Validation MAE��', num2str(MAE2)])

 %RMSE
  RMSE1(i) = sqrt(mean((T_train -T_sim1').^2));     
  RMSE2(i) = sqrt(mean((T_test - T_sim2').^2));
  disp(['Calibration RMSE��', num2str(RMSE1)])
  disp(['Validation RMSE��', num2str(RMSE2)])
 
 %rRMSE
   rRMSE1(i) = sqrt(mean((T_train -T_sim1').^2))./mean(T_train);     
   rRMSE2(i) = sqrt(mean((T_test - T_sim2').^2))./mean(T_test);
   disp(['Calibration rRMSE��', num2str(rRMSE1)])
   disp(['Validation rRMSE��', num2str(rRMSE2)])
  
   if rRMSE2(i)<= besterror  
        save('ks','net');
        besterror=rRMSE2(i);    
        best_option=i;          
        i
        best_option
    end

end
figure;
plot(rRMSE1,'r.-');hold on;
plot(rRMSE2,'-*');hold on
xlabel('feature number');
ylabel(fitting accuracy');
legend('calibration','validation');

load ks     
p_test1 = p_test (:, save_index(1:best_option));   
p_train1= p_train(:, save_index(1:best_option));  

t_sim3 = predict(net, p_train1 );
t_sim4 = predict(net, p_test1 );

T_sim3 = mapminmax('reverse', t_sim3, ps_output); 
T_sim4 = mapminmax('reverse', t_sim4, ps_output); 

error3 = sqrt(sum((T_train - T_sim3').^2) ./ M);  
error4 = sqrt(sum((T_test - T_sim4').^2) ./ N);  

%  R2
R3 = 1-(sum((T_train - T_sim3').^2)/sum((T_train -  mean(T_train)).^2)) ;
R4 = 1-(sum((T_test - T_sim4').^2)/sum((T_test -  mean(T_test)).^2)) ;
disp([' Optimal calibration R2��', num2str(R3)])
disp([' Optimal validation R2��', num2str(R4)])

%MAE
MAE3 = sum(abs( T_train -T_sim3'))./ M ;
MAE4 = sum(abs( T_test -T_sim4'))./ N ;
disp(['Optimal calibration MAE��', num2str(MAE3)]);
disp(['Optimal validation MAE��', num2str(MAE4)]);


%RMSE
rmse3 = sqrt(mean((T_train - T_sim3').^2));
rmse4 = sqrt(mean((T_test - T_sim4').^2));
disp(['Optimal calibration RMSE��', num2str(rmse3)])
disp(['Optimal validation RMSE��', num2str(rmse4)])


%rRMSE  
rRMSE3 = sqrt(mean((T_train - T_sim3').^2))./mean(T_train);
rRMSE4 = sqrt(mean((T_test - T_sim4').^2))./mean(T_test);
disp([' Optimal calibration rRMSE��', num2str(rRMSE3)])
disp([' Optimal validation rRMSE��', num2str(rRMSE4)])
