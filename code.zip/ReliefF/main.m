warning off            
close all           
clear                   
clc                     

res = xlsread('data.xlsx');

num_size = 1;                               
outdim = 1;  
num_samples = size(res, 1);                  
%res = res(randperm(num_samples), :);        
num_train_s = round(num_size * num_samples); 
f_ = size(res, 2) - outdim;                  

P_train = res(1: num_train_s, 1: f_)';
T_train = res(1: num_train_s, f_ + 1: end)';
M = size(P_train, 2);

[p_train, ps_input] = mapminmax(P_train, 0, 1);
[t_train, ps_output] = mapminmax(T_train, 0, 1);

p_train = p_train';
t_train = t_train'; 

size(p_train)
size(t_train)

k = "your feature number" ;        
[index, weights] = relieff(p_train, t_train, k);

bar(weights)
xlabel('No. feature')
ylabel('Importance')

save_index = index(1: k)';

disp('After selection��')
disp(save_index')

p_train = p_train(:, save_index);


